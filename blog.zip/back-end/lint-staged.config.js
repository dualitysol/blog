module.exports = {
  "*.{js,jsx,vue}": "npm lint",
};
