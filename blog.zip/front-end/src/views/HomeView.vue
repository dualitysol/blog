<template>
  <v-container>
    <v-row>
      <v-col>
        <h1>Posts</h1>
      </v-col>
    </v-row>
  </v-container>
</template>

<script>
import { defineComponent } from "vue";

export default defineComponent({
  name: "HomeView",

  components: {},
});
</script>
